from django.urls import path, include
from core.views import dashboard  # Asegúrate de que esto esté correcto

urlpatterns = [
    path('', dashboard, name='dashboard'),
    path('inventario/', include('inventario.urls')),
    path('ventas/', include('ventas.urls')),
]
