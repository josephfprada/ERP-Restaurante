from django.shortcuts import render, redirect, get_object_or_404
from .models import Producto
from .forms import ProductoForm
from django.contrib import messages
from django.core.paginator import Paginator

def listar_productos(request):
    filtro = request.GET.get('filtro', '')
    productos = Producto.objects.filter(nombre__icontains=filtro)
    paginador = Paginator(productos, 5)
    pagina = request.GET.get('page')
    productos_pagina = paginador.get_page(pagina)
    return render(request, 'inventario/listar.html', {
        'productos': productos_pagina,
        'filtro': filtro
    })

def crear_producto(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Producto creado con éxito.")
            return redirect('listar_productos')
    else:
        form = ProductoForm()
    return render(request, 'inventario/formulario.html', {'form': form, 'accion': 'Crear'})

def editar_producto(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == 'POST':
        form = ProductoForm(request.POST, instance=producto)
        if form.is_valid():
            form.save()
            messages.success(request, "Producto actualizado.")
            return redirect('listar_productos')
    else:
        form = ProductoForm(instance=producto)
    return render(request, 'inventario/formulario.html', {'form': form, 'accion': 'Editar'})

def eliminar_producto(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == 'POST':
        producto.delete()
        messages.success(request, "Producto eliminado.")
        return redirect('listar_productos')
    return render(request, 'inventario/eliminar_confirmacion.html', {'producto': producto})


import csv
from django.http import HttpResponse
from .models import Producto

def exportar_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="inventario.csv"'

    writer = csv.writer(response)
    writer.writerow(['Nombre', 'Descripción', 'Precio', 'Stock', 'Unidad'])

    for producto in Producto.objects.all():
        writer.writerow([producto.nombre, producto.descripcion, producto.precio, producto.stock, producto.unidad_medida])

    return response


from django.http import HttpResponse
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from .models import Producto

def exportar_pdf(request):
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="inventario.pdf"'

    p = canvas.Canvas(response, pagesize=letter)
    width, height = letter
    y = height - 50

    p.setFont("Helvetica-Bold", 16)
    p.drawString(200, y, "Inventario de Productos")
    y -= 40

    p.setFont("Helvetica-Bold", 10)
    p.drawString(30, y, "Nombre")
    p.drawString(150, y, "Descripción")
    p.drawString(300, y, "Precio")
    p.drawString(360, y, "Stock")
    p.drawString(420, y, "Unidad")
    y -= 20

    p.setFont("Helvetica", 10)
    for producto in Producto.objects.all():
        if y < 50:
            p.showPage()
            y = height - 50
        p.drawString(30, y, producto.nombre[:20])
        p.drawString(150, y, producto.descripcion[:25])
        p.drawString(300, y, f"${producto.precio}")
        p.drawString(360, y, str(producto.stock))
        p.drawString(420, y, producto.unidad_medida)
        y -= 20

    p.showPage()
    p.save()
    return response
