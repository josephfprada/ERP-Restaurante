from django.urls import path
from .views import ventas_completo, generar_factura

urlpatterns = [
    path('', ventas_completo, name='ventas_completo'),
    path('factura/<int:venta_id>/', generar_factura, name='generar_factura'),
]
