from django.shortcuts import render, redirect
from django.utils import timezone
from django.http import FileResponse, HttpResponse
from .models import Venta, DetalleVenta
from inventario.models import Producto
import io
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

def ventas_completo(request):
    productos = Producto.objects.all()

    if request.method == 'POST':
        producto_id = request.POST.get('producto')
        cantidad_raw = request.POST.get('cantidad')
        cliente = request.POST.get('cliente', 'Anónimo')
        forma_pago = request.POST.get('forma_pago', 'EFECTIVO')

        if not producto_id or not cantidad_raw:
            return render(request, 'ventas/ventas_completo.html', {
                'productos': productos,
                'error': 'Debe completar todos los campos.'
            })

        try:
            cantidad = int(cantidad_raw)
        except ValueError:
            return render(request, 'ventas/ventas_completo.html', {
                'productos': productos,
                'error': 'La cantidad debe ser un número válido.'
            })

        try:
            producto = Producto.objects.get(pk=producto_id)
        except Producto.DoesNotExist:
            return render(request, 'ventas/ventas_completo.html', {
                'productos': productos,
                'error': 'Producto no encontrado.'
            })

        if producto.stock < cantidad:
            return render(request, 'ventas/ventas_completo.html', {
                'productos': productos,
                'error': 'Stock insuficiente.'
            })

        venta = Venta.objects.create(
            fecha=timezone.now(),
            cliente=cliente,
            forma_pago=forma_pago
        )

        DetalleVenta.objects.create(
            venta=venta,
            producto=producto,
            cantidad=cantidad,
            precio_unitario=producto.precio
        )

        producto.stock -= cantidad
        producto.save()

        return redirect('ventas_completo')

    # Historial de ventas
    ventas = DetalleVenta.objects.select_related('venta', 'producto').all()

    contexto = {
        'productos': productos,
        'ventas': [{
            'fecha': v.venta.fecha.strftime("%d de %B de %Y a las %H:%M"),
            'cliente': v.venta.cliente,
            'producto': v.producto.nombre,
            'cantidad': v.cantidad,
            'total': v.cantidad * v.precio_unitario,
            'id': v.venta.id
        } for v in ventas]
    }

    return render(request, 'ventas/ventas_completo.html', contexto)


def generar_factura(request, venta_id):
    try:
        venta = Venta.objects.get(id=venta_id)
        detalles = DetalleVenta.objects.filter(venta=venta)
    except Venta.DoesNotExist:
        return HttpResponse("Venta no encontrada", status=404)

    buffer = io.BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter

    p.setFont("Helvetica-Bold", 14)
    p.drawString(50, height - 50, "Factura de Venta")
    p.setFont("Helvetica", 12)
    p.drawString(50, height - 80, f"ID de venta: {venta.id}")
    p.drawString(50, height - 100, f"Fecha: {venta.fecha.strftime('%Y-%m-%d %H:%M')}")
    p.drawString(50, height - 120, f"Cliente: {venta.cliente}")

    y = height - 160
    p.drawString(50, y, "Producto")
    p.drawString(250, y, "Cantidad")
    p.drawString(350, y, "Subtotal")

    total = 0
    for detalle in detalles:
        subtotal = detalle.subtotal()
        total += subtotal
        y -= 20
        p.drawString(50, y, detalle.producto.nombre)
        p.drawString(250, y, str(detalle.cantidad))
        p.drawString(350, y, f"${subtotal:.2f}")

    y -= 40
    p.setFont("Helvetica-Bold", 12)
    p.drawString(50, y, f"Total venta: ${total:.2f}")

    p.showPage()
    p.save()
    buffer.seek(0)
    return FileResponse(buffer, as_attachment=True, filename=f"factura_venta_{venta.id}.pdf")
