from django.db import models
from inventario.models import Producto
from django.utils import timezone

FORMAS_PAGO = [
    ('EFECTIVO', 'Efectivo'),
    ('TARJETA', 'Tarjeta'),
    ('TRANSFERENCIA', 'Transferencia'),
]

class Venta(models.Model):
    fecha = models.DateTimeField(default=timezone.now)
    cliente = models.CharField(max_length=100, blank=True)
    forma_pago = models.CharField(max_length=20, choices=FORMAS_PAGO, default='EFECTIVO')
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def __str__(self):
        return f"Venta #{self.id} - {self.fecha.date()}"

class DetalleVenta(models.Model):
    venta = models.ForeignKey(Venta, related_name='detalles', on_delete=models.CASCADE)
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField()
    precio_unitario = models.DecimalField(max_digits=10, decimal_places=2)

    def subtotal(self):
        return self.cantidad * self.precio_unitario

    def __str__(self):
        return f"{self.cantidad} x {self.producto.nombre}"
