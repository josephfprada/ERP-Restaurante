from django.contrib import admin
from .models import ProductoInventario

@admin.register(ProductoInventario)
class ProductoInventarioAdmin(admin.ModelAdmin):
    list_display = ['producto', 'stock']
    search_fields = ['producto__nombre']
