from django.db import models
from clientes_proveedores.models import ProductoProveedor

class MovimientoInventario(models.Model):
    TIPO_MOVIMIENTO = [
        ('ENTRADA', 'Entrada'),
        ('SALIDA', 'Salida'),
        ('AJUSTE', 'Ajuste'),
    ]

    producto_inventario = models.ForeignKey('ProductoInventario', on_delete=models.CASCADE, related_name='movimientos')
    tipo = models.CharField(max_length=10, choices=TIPO_MOVIMIENTO)
    cantidad = models.IntegerField()
    fecha = models.DateTimeField(auto_now_add=True)
    descripcion = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.get_tipo_display()} - {self.cantidad} - {self.producto_inventario.producto.nombre}"


class ProductoInventario(models.Model):
    producto = models.OneToOneField(
        ProductoProveedor,
        on_delete=models.CASCADE,
        related_name='inventario_producto_inventario'
    )
    stock = models.PositiveIntegerField(default=0)
    stock_minimo = models.PositiveIntegerField(default=10)

    def stock_bajo(self):
        return self.stock <= self.stock_minimo

    def __str__(self):
        return f"{self.producto.nombre} - Stock: {self.stock}"
