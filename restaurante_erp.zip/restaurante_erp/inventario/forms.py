from django import forms
from .models import ProductoInventario

class ProductoInventarioForm(forms.ModelForm):
    class Meta:
        model = ProductoInventario
        fields = ['producto', 'stock']
