from django.urls import path

from . import views

urlpatterns = [

    path('exportar/csv/', views.exportar_inventario_csv, name='exportar_inventario_csv'),
    path('', views.lista_inventario, name='lista_inventario'),
    path('nuevo/', views.crear_producto_inventario, name='crear_producto_inventario'),
    path('editar/<int:pk>/', views.editar_producto_inventario, name='editar_producto_inventario'),
    path('eliminar/<int:pk>/', views.eliminar_producto_inventario, name='eliminar_producto_inventario'),
]
