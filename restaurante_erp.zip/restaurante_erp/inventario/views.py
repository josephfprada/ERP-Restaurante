import csv
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from .models import ProductoInventario
from .forms import ProductoInventarioForm

def lista_inventario(request):
    productos = ProductoInventario.objects.select_related('producto').all()
    return render(request, 'inventario/lista_inventario.html', {'productos': productos})

def crear_producto_inventario(request):
    if request.method == 'POST':
        form = ProductoInventarioForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_inventario')
    else:
        form = ProductoInventarioForm()
    return render(request, 'inventario/form_producto_inventario.html', {'form': form})

def editar_producto_inventario(request, pk):
    producto = get_object_or_404(ProductoInventario, pk=pk)
    if request.method == 'POST':
        form = ProductoInventarioForm(request.POST, instance=producto)
        if form.is_valid():
            form.save()
            return redirect('lista_inventario')
    else:
        form = ProductoInventarioForm(instance=producto)
    return render(request, 'inventario/form_producto_inventario.html', {'form': form})

def eliminar_producto_inventario(request, pk):
    producto = get_object_or_404(ProductoInventario, pk=pk)
    if request.method == 'POST':
        producto.delete()
        return redirect('lista_inventario')
    return render(request, 'inventario/confirmar_eliminacion.html', {'producto': producto})



def exportar_inventario_csv(request):
    productos = ProductoInventario.objects.select_related('producto').all()

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="inventario.csv"'

    writer = csv.writer(response)
    writer.writerow(['Producto', 'Stock', 'Stock Mínimo'])

    for p in productos:
        writer.writerow([p.producto.nombre, p.stock, p.stock_minimo])

    return response
