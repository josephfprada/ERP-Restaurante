from django.shortcuts import render, redirect
from django.forms import inlineformset_factory
from .models import Venta, DetalleVenta
from .forms import VentaForm, DetalleVentaForm
from django.shortcuts import get_object_or_404
from django.db.models import Q
from django.utils.dateparse import parse_date
from django.db import transaction
from inventario.models import ProductoInventario
from . import forms


def lista_ventas(request):
    ventas = Venta.objects.all().order_by('-fecha')
    return render(request, 'ventas/lista_ventas.html', {'ventas': ventas})

def crear_venta(request):
    DetalleFormSet = inlineformset_factory(Venta, DetalleVenta, form=DetalleVentaForm, extra=1, can_delete=True)
    if request.method == 'POST':
        form = VentaForm(request.POST)
        formset = DetalleFormSet(request.POST)
        if form.is_valid() and formset.is_valid():
            venta = form.save(commit=False)
            venta.total = 0
            venta.save()
            detalles = formset.save(commit=False)
            total = 0
            for detalle in detalles:
                detalle.venta = venta
                detalle.precio_unitario = detalle.producto.precio
                detalle.subtotal = detalle.cantidad * detalle.precio_unitario
                detalle.save()
                total += detalle.subtotal
            venta.total = total
            venta.save()
            return redirect('lista_ventas')
    else:
        form = VentaForm()
        formset = DetalleFormSet()
    return render(request, 'ventas/crear_venta.html', {'form': form, 'formset': formset})



def editar_venta(request, pk):
    venta = get_object_or_404(Venta, pk=pk)
    DetalleFormSet = inlineformset_factory(Venta, DetalleVenta, form=DetalleVentaForm, extra=1, can_delete=True)
    if request.method == 'POST':
        form = VentaForm(request.POST, instance=venta)
        formset = DetalleFormSet(request.POST, instance=venta)
        if form.is_valid() and formset.is_valid():
            with transaction.atomic():
                venta = form.save(commit=False)
                total = 0
                detalles_anterior = {d.id: d for d in venta.detalles.all()}

                detalles = formset.save(commit=False)
                for detalle in detalles:
                    prod_inv = ProductoInventario.objects.get(producto=detalle.producto)

                    if detalle.id:  # detalle existente
                        anterior = detalles_anterior.get(detalle.id)
                        diff = detalle.cantidad - anterior.cantidad
                    else:
                        diff = detalle.cantidad

                    if diff > 0 and prod_inv.stock < diff:
                        raise forms.ValidationError(f"Stock insuficiente para {detalle.producto.nombre}.")

                    prod_inv.stock -= diff
                    prod_inv.save()

                    detalle.venta = venta
                    detalle.precio_unitario = detalle.producto.precio
                    detalle.subtotal = detalle.cantidad * detalle.precio_unitario
                    detalle.save()

                    total += detalle.subtotal

                # Reponer stock de detalles eliminados
                for detalle_elim in formset.deleted_objects:
                    prod_inv = ProductoInventario.objects.get(producto=detalle_elim.producto)
                    prod_inv.stock += detalle_elim.cantidad
                    prod_inv.save()
                    detalle_elim.delete()

                venta.total = total
                venta.save()
            return redirect('lista_ventas')
    else:
        form = VentaForm(instance=venta)
        formset = DetalleFormSet(instance=venta)
    return render(request, 'ventas/crear_venta.html', {'form': form, 'formset': formset})

def eliminar_venta(request, pk):
    venta = get_object_or_404(Venta, pk=pk)
    if request.method == 'POST':
        venta.delete()
        return redirect('lista_ventas')
    return render(request, 'ventas/confirmar_eliminacion.html', {'venta': venta})


def lista_ventas(request):
    ventas = Venta.objects.all().order_by('-fecha')

    cliente_query = request.GET.get('cliente', '').strip()
    fecha_desde = request.GET.get('fecha_desde', '')
    fecha_hasta = request.GET.get('fecha_hasta', '')

    if cliente_query:
        ventas = ventas.filter(cliente__nombre__icontains=cliente_query)
    if fecha_desde:
        ventas = ventas.filter(fecha__date__gte=parse_date(fecha_desde))
    if fecha_hasta:
        ventas = ventas.filter(fecha__date__lte=parse_date(fecha_hasta))

    context = {
        'ventas': ventas,
        'cliente_query': cliente_query,
        'fecha_desde': fecha_desde,
        'fecha_hasta': fecha_hasta,
    }
    return render(request, 'ventas/lista_ventas.html', context)



def editar_venta(request, pk):
    venta = get_object_or_404(Venta, pk=pk)
    DetalleFormSet = inlineformset_factory(Venta, DetalleVenta, form=DetalleVentaForm, extra=1, can_delete=True)
    if request.method == 'POST':
        form = VentaForm(request.POST, instance=venta)
        formset = DetalleFormSet(request.POST, instance=venta)
        if form.is_valid() and formset.is_valid():
            venta = form.save(commit=False)
            total = 0
            detalles = formset.save(commit=False)
            for detalle in detalles:
                detalle.precio_unitario = detalle.producto.precio
                detalle.subtotal = detalle.cantidad * detalle.precio_unitario
                detalle.venta = venta
                detalle.save()
                total += detalle.subtotal
            # Eliminar detalles marcados para eliminar
            for detalle in formset.deleted_objects:
                detalle.delete()
            venta.total = total
            venta.save()
            return redirect('lista_ventas')
    else:
        form = VentaForm(instance=venta)
        formset = DetalleFormSet(instance=venta)
    return render(request, 'ventas/crear_venta.html', {'form': form, 'formset': formset})




def crear_venta(request):
    DetalleFormSet = inlineformset_factory(Venta, DetalleVenta, form=DetalleVentaForm, extra=1, can_delete=True)
    if request.method == 'POST':
        form = VentaForm(request.POST)
        formset = DetalleFormSet(request.POST)
        if form.is_valid() and formset.is_valid():
            with transaction.atomic():
                venta = form.save(commit=False)
                venta.total = 0
                venta.save()

                total = 0
                for detalle in formset.save(commit=False):
                    detalle.venta = venta
                    detalle.precio_unitario = detalle.producto.precio
                    detalle.subtotal = detalle.cantidad * detalle.precio_unitario

                    # Actualizar inventario restando stock
                    inventario = ProductoInventario.objects.get(producto=detalle.producto)
                    if inventario.stock < detalle.cantidad:
                        raise forms.ValidationError(f"Stock insuficiente para {detalle.producto.nombre}.")
                    inventario.stock -= detalle.cantidad
                    inventario.save()

                    detalle.save()
                    total += detalle.subtotal

                venta.total = total
                venta.save()
            return redirect('lista_ventas')
    else:
        form = VentaForm()
        formset = DetalleFormSet()
    return render(request, 'ventas/crear_venta.html', {'form': form, 'formset': formset})
