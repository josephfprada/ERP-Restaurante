from django import forms
from .models import Venta, DetalleVenta
from clientes_proveedores.models import Cliente, ProductoProveedor
from django.core.exceptions import ValidationError
from django import forms
from .models import DetalleVenta
from inventario.models import ProductoInventario

class VentaForm(forms.ModelForm):
    class Meta:
        model = Venta
        fields = ['cliente', 'forma_pago']

class DetalleVentaForm(forms.ModelForm):
    class Meta:
        model = DetalleVenta
        fields = ['producto', 'cantidad']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['producto'].queryset = ProductoProveedor.objects.all()



class DetalleVentaForm(forms.ModelForm):
    class Meta:
        model = DetalleVenta
        fields = ['producto', 'cantidad']

    def clean_cantidad(self):
        cantidad = self.cleaned_data.get('cantidad')
        if cantidad is None or cantidad <= 0:
            raise ValidationError("La cantidad debe ser mayor que cero.")
        return cantidad



class DetalleVentaForm(forms.ModelForm):
    class Meta:
        model = DetalleVenta
        fields = ['producto', 'cantidad']

    def clean(self):
        cleaned_data = super().clean()
        producto = cleaned_data.get('producto')
        cantidad = cleaned_data.get('cantidad')

        if producto and cantidad:
            try:
                inventario = ProductoInventario.objects.get(producto=producto)
            except ProductoInventario.DoesNotExist:
                raise forms.ValidationError(f"No se encontró inventario para el producto {producto.nombre}.")

            if cantidad <= 0:
                raise forms.ValidationError("La cantidad debe ser mayor que cero.")

            if cantidad > inventario.stock:
                raise forms.ValidationError(f"Cantidad solicitada ({cantidad}) excede el stock disponible ({inventario.stock}).")

        return cleaned_data
