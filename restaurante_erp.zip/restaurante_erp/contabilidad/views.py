from django.shortcuts import render, redirect, get_object_or_404
from .models import CuentaContable, TransaccionContable
from .forms import CuentaContableForm, TransaccionContableForm
from django.db.models import Sum
from django.shortcuts import redirect
from django.db.models.functions import Lower
from django.shortcuts import render

def index_contabilidad(request):
    return render(request, 'contabilidad/index.html')
def lista_cuentas(request):
    cuentas = CuentaContable.objects.all().order_by('codigo')
    return render(request, 'contabilidad/lista_cuentas.html', {'cuentas': cuentas})


def crear_cuenta(request):
    if request.method == 'POST':
        form = CuentaContableForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_cuentas')
    else:
        form = CuentaContableForm()
    return render(request, 'contabilidad/form_cuenta.html', {'form': form})


def lista_transacciones(request):
    transacciones = TransaccionContable.objects.select_related('cuenta').all().order_by('-fecha')
    return render(request, 'contabilidad/lista_transacciones.html', {'transacciones': transacciones})


def crear_transaccion(request):
    if request.method == 'POST':
        form = TransaccionContableForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_transacciones')
    else:
        form = TransaccionContableForm()
    return render(request, 'contabilidad/form_transaccion.html', {'form': form})


def editar_cuenta(request, pk):
    cuenta = get_object_or_404(CuentaContable, pk=pk)
    if request.method == 'POST':
        form = CuentaContableForm(request.POST, instance=cuenta)
        if form.is_valid():
            form.save()
            return redirect('lista_cuentas')
    else:
        form = CuentaContableForm(instance=cuenta)
    return render(request, 'contabilidad/form_cuenta.html', {'form': form})


def eliminar_cuenta(request, pk):
    cuenta = get_object_or_404(CuentaContable, pk=pk)
    if request.method == 'POST':
        cuenta.delete()
        return redirect('lista_cuentas')
    return render(request, 'contabilidad/confirmar_eliminacion_cuenta.html', {'cuenta': cuenta})


def editar_transaccion(request, pk):
    transaccion = get_object_or_404(TransaccionContable, pk=pk)
    if request.method == 'POST':
        form = TransaccionContableForm(request.POST, instance=transaccion)
        if form.is_valid():
            form.save()
            return redirect('lista_transacciones')
    else:
        form = TransaccionContableForm(instance=transaccion)
    return render(request, 'contabilidad/form_transaccion.html', {'form': form})


def eliminar_transaccion(request, pk):
    transaccion = get_object_or_404(TransaccionContable, pk=pk)
    if request.method == 'POST':
        transaccion.delete()
        return redirect('lista_transacciones')
    return render(request, 'contabilidad/confirmar_eliminacion_transaccion.html', {'transaccion': transaccion})


def calcular_saldo_cuenta(cuenta):
    # Obtener la cuenta y todas sus subcuentas recursivamente
    cuentas = [cuenta]
    cuentas += list(cuenta.subcuentas.all())

    debe_total = TransaccionContable.objects.filter(cuenta__in=cuentas).aggregate(total=Sum('debe'))['total'] or 0
    haber_total = TransaccionContable.objects.filter(cuenta__in=cuentas).aggregate(total=Sum('haber'))['total'] or 0

    saldo = debe_total - haber_total
    return saldo



def balance_general(request):
    activos = CuentaContable.objects.annotate(
        codigo_lower=Lower('codigo')
    ).filter(codigo_lower__startswith='1')

    pasivos = CuentaContable.objects.annotate(
        codigo_lower=Lower('codigo')
    ).filter(codigo_lower__startswith='2')

    patrimonio = CuentaContable.objects.annotate(
        codigo_lower=Lower('codigo')
    ).filter(codigo_lower__startswith='3')
    activos_saldos = [(cuenta, calcular_saldo_cuenta(cuenta)) for cuenta in activos]
    pasivos_saldos = [(cuenta, calcular_saldo_cuenta(cuenta)) for cuenta in pasivos]
    patrimonio_saldos = [(cuenta, calcular_saldo_cuenta(cuenta)) for cuenta in patrimonio]

    context = {
        'activos_saldos': activos_saldos,
        'pasivos_saldos': pasivos_saldos,
        'patrimonio_saldos': patrimonio_saldos,
    }
    return render(request, 'contabilidad/balance_general.html', context)


def estado_resultados(request):
    ingresos = CuentaContable.objects.filter(codigo__startswith='4').order_by('codigo')
    gastos = CuentaContable.objects.filter(codigo__startswith='5').order_by('codigo')

    ingresos_saldos = [(cuenta, calcular_saldo_cuenta(cuenta)) for cuenta in ingresos]
    gastos_saldos = [(cuenta, calcular_saldo_cuenta(cuenta)) for cuenta in gastos]

    total_ingresos = sum(saldo for _, saldo in ingresos_saldos)
    total_gastos = sum(saldo for _, saldo in gastos_saldos)
    utilidad = total_ingresos - total_gastos

    context = {
        'ingresos_saldos': ingresos_saldos,
        'gastos_saldos': gastos_saldos,
        'total_ingresos': total_ingresos,
        'total_gastos': total_gastos,
        'utilidad': utilidad,
    }
    return render(request, 'contabilidad/estado_resultados.html', context)
