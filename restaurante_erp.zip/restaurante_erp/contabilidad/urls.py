from django.urls import path
from . import views

urlpatterns = [
    path('', views.index_contabilidad, name='index_contabilidad'),
    path('reportes/balance-general/', views.balance_general, name='balance_general'),
    path('reportes/estado-resultados/', views.estado_resultados, name='estado_resultados'),

    path('cuentas/', views.lista_cuentas, name='lista_cuentas'),
    path('cuentas/nueva/', views.crear_cuenta, name='crear_cuenta'),
    path('cuentas/editar/<int:pk>/', views.editar_cuenta, name='editar_cuenta'),
    path('cuentas/eliminar/<int:pk>/', views.eliminar_cuenta, name='eliminar_cuenta'),

    path('transacciones/', views.lista_transacciones, name='lista_transacciones'),
    path('transacciones/nueva/', views.crear_transaccion, name='crear_transaccion'),
    path('transacciones/editar/<int:pk>/', views.editar_transaccion, name='editar_transaccion'),
    path('transacciones/eliminar/<int:pk>/', views.eliminar_transaccion, name='eliminar_transaccion'),
]
