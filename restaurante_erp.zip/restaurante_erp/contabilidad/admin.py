from django.contrib import admin
from .models import CuentaContable, TransaccionContable

@admin.register(CuentaContable)
class CuentaContableAdmin(admin.ModelAdmin):
    list_display = ['codigo', 'nombre', 'cuenta_padre', 'es_cuenta_detalle']
    search_fields = ['codigo', 'nombre']

@admin.register(TransaccionContable)
class TransaccionContableAdmin(admin.ModelAdmin):
    list_display = ['fecha', 'descripcion', 'cuenta', 'debe', 'haber']
    list_filter = ['fecha', 'cuenta']
    search_fields = ['descripcion']
