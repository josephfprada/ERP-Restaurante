from django.db import models

class CuentaContable(models.Model):
    codigo = models.CharField(max_length=20, unique=True)
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField(blank=True, null=True)
    es_cuenta_detalle = models.BooleanField(default=True)  # Para cuentas de mayor o detalle
    cuenta_padre = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='subcuentas')

    def __str__(self):
        return f"{self.codigo} - {self.nombre}"

class TransaccionContable(models.Model):
    fecha = models.DateField()  # o usar auto_now_add=True si no quieres que sea editable
    descripcion = models.CharField(max_length=255)
    cuenta = models.ForeignKey(CuentaContable, on_delete=models.PROTECT)
    debe = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    haber = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    def __str__(self):
        return f"{self.fecha} - {self.descripcion} - {self.cuenta.nombre}"
