from django import forms
from .models import CuentaContable, TransaccionContable

class CuentaContableForm(forms.ModelForm):
    class Meta:
        model = CuentaContable
        fields = ['codigo', 'nombre', 'descripcion', 'es_cuenta_detalle', 'cuenta_padre']

class TransaccionContableForm(forms.ModelForm):
    class Meta:
        model = TransaccionContable
        fields = ['fecha', 'descripcion', 'cuenta', 'debe', 'haber']
