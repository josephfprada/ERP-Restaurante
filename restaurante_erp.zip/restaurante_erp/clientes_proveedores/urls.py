from django.urls import path
from . import views

urlpatterns = [
    path('', views.index_clientes_proveedores, name='index_clientes_proveedores'),
    # Rutas existentes:
    path('clientes/', views.lista_clientes, name='lista_clientes'),
    path('clientes/nuevo/', views.crear_cliente, name='crear_cliente'),
    path('clientes/editar/<int:pk>/', views.editar_cliente, name='editar_cliente'),
    path('clientes/eliminar/<int:pk>/', views.eliminar_cliente, name='eliminar_cliente'),

    path('proveedores/', views.lista_proveedores, name='lista_proveedores'),
    path('proveedores/nuevo/', views.crear_proveedor, name='crear_proveedor'),
    path('proveedores/editar/<int:pk>/', views.editar_proveedor, name='editar_proveedor'),
    path('proveedores/eliminar/<int:pk>/', views.eliminar_proveedor, name='eliminar_proveedor'),

    path('productos/', views.lista_productos_proveedor, name='lista_productos'),
    path('productos/nuevo/', views.crear_producto_proveedor, name='crear_producto'),
    path('productos/editar/<int:pk>/', views.editar_producto_proveedor, name='editar_producto'),
    path('productos/eliminar/<int:pk>/', views.eliminar_producto_proveedor, name='eliminar_producto'),

    path('comparar-precios/', views.comparar_precios, name='comparar_precios'),
]
