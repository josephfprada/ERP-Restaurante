from django.contrib import admin
from .models import Cliente, Proveedor, ProductoProveedor

admin.site.register(Cliente)
admin.site.register(Proveedor)
admin.site.register(ProductoProveedor)
