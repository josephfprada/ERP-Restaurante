from django.shortcuts import render, redirect, get_object_or_404
from .models import Cliente, Proveedor, ProductoProveedor
from .forms import ClienteForm, ProveedorForm, ProductoProveedorForm


def index_clientes_proveedores(request):
    return render(request, 'clientes_proveedores/index.html')
# ---------- Clientes ----------

def lista_clientes(request):
    clientes = Cliente.objects.all()
    return render(request, 'clientes_proveedores/lista_clientes.html', {'clientes': clientes})

def crear_cliente(request):
    if request.method == 'POST':
        form = ClienteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_clientes')
    else:
        form = ClienteForm()
    return render(request, 'clientes_proveedores/form_cliente.html', {'form': form})

def editar_cliente(request, pk):
    cliente = get_object_or_404(Cliente, pk=pk)
    if request.method == 'POST':
        form = ClienteForm(request.POST, instance=cliente)
        if form.is_valid():
            form.save()
            return redirect('lista_clientes')
    else:
        form = ClienteForm(instance=cliente)
    return render(request, 'clientes_proveedores/form_cliente.html', {'form': form})

def eliminar_cliente(request, pk):
    cliente = get_object_or_404(Cliente, pk=pk)
    cliente.delete()
    return redirect('lista_clientes')

# ---------- Proveedores ----------

def lista_proveedores(request):
    proveedores = Proveedor.objects.all()
    return render(request, 'clientes_proveedores/lista_proveedores.html', {'proveedores': proveedores})

def crear_proveedor(request):
    if request.method == 'POST':
        form = ProveedorForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_proveedores')
    else:
        form = ProveedorForm()
    return render(request, 'clientes_proveedores/form_proveedor.html', {'form': form})

def editar_proveedor(request, pk):
    proveedor = get_object_or_404(Proveedor, pk=pk)
    if request.method == 'POST':
        form = ProveedorForm(request.POST, instance=proveedor)
        if form.is_valid():
            form.save()
            return redirect('lista_proveedores')
    else:
        form = ProveedorForm(instance=proveedor)
    return render(request, 'clientes_proveedores/form_proveedor.html', {'form': form})

def eliminar_proveedor(request, pk):
    proveedor = get_object_or_404(Proveedor, pk=pk)
    proveedor.delete()
    return redirect('lista_proveedores')

# ---------- Productos Proveedor ----------

def lista_productos_proveedor(request):
    productos = ProductoProveedor.objects.select_related('proveedor').all()
    return render(request, 'clientes_proveedores/lista_productos.html', {'productos': productos})

def crear_producto_proveedor(request):
    if request.method == 'POST':
        form = ProductoProveedorForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_productos')
    else:
        form = ProductoProveedorForm()
    return render(request, 'clientes_proveedores/form_producto.html', {'form': form})

def editar_producto_proveedor(request, pk):
    producto = get_object_or_404(ProductoProveedor, pk=pk)
    if request.method == 'POST':
        form = ProductoProveedorForm(request.POST, instance=producto)
        if form.is_valid():
            form.save()
            return redirect('lista_productos')
    else:
        form = ProductoProveedorForm(instance=producto)
    return render(request, 'clientes_proveedores/form_producto.html', {'form': form})

def eliminar_producto_proveedor(request, pk):
    producto = get_object_or_404(ProductoProveedor, pk=pk)
    producto.delete()
    return redirect('lista_productos')

# ---------- Comparar Precios ----------

def comparar_precios(request):
    # Obtener nombres de productos únicos ordenados
    productos_unicos = ProductoProveedor.objects.values_list('nombre', flat=True).distinct().order_by('nombre')
    seleccion = request.GET.get('producto')

    productos_filtrados = []
    if seleccion:
        productos_filtrados = ProductoProveedor.objects.filter(nombre=seleccion).select_related('proveedor')

    context = {
        'productos_unicos': productos_unicos,
        'productos_filtrados': productos_filtrados,
        'seleccion': seleccion
    }
    return render(request, 'clientes_proveedores/comparar_precios.html', context)
