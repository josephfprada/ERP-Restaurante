import csv
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from .models import Empleado
from .forms import EmpleadoForm

def lista_empleados(request):
    empleados = Empleado.objects.all()
    return render(request, 'rrhh/lista_empleados.html', {'empleados': empleados})

def crear_empleado(request):
    if request.method == 'POST':
        form = EmpleadoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_empleados')
    else:
        form = EmpleadoForm()
    return render(request, 'rrhh/form_empleado.html', {'form': form})

def editar_empleado(request, pk):
    empleado = get_object_or_404(Empleado, pk=pk)
    if request.method == 'POST':
        form = EmpleadoForm(request.POST, instance=empleado)
        if form.is_valid():
            form.save()
            return redirect('lista_empleados')
    else:
        form = EmpleadoForm(instance=empleado)
    return render(request, 'rrhh/form_empleado.html', {'form': form})

def eliminar_empleado(request, pk):
    empleado = get_object_or_404(Empleado, pk=pk)
    empleado.delete()
    return redirect('lista_empleados')

def exportar_empleados_csv(request):
    empleados = Empleado.objects.all()

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="empleados.csv"'

    writer = csv.writer(response)
    writer.writerow(['Nombre', 'Apellido', 'Documento', 'Teléfono', 'Email', 'Cargo', 'Salario'])

    for emp in empleados:
        writer.writerow([emp.nombre, emp.apellido, emp.documento_identidad, emp.telefono, emp.email, emp.cargo, emp.salario])

    return response

