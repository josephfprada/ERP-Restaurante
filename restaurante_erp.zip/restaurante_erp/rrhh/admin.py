from django.contrib import admin
from import_export import resources
from import_export.admin import ExportMixin
from .models import Empleado

class EmpleadoResource(resources.ModelResource):
    class Meta:
        model = Empleado

class EmpleadoAdmin(ExportMixin, admin.ModelAdmin):
    resource_class = EmpleadoResource
    list_display = ('nombre', 'apellido', 'documento_identidad', 'telefono', 'email', 'cargo', 'salario')

admin.site.register(Empleado, EmpleadoAdmin)
