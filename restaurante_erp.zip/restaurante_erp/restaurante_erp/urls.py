from django.contrib import admin
from django.urls import path, include
from core.views import dashboard
from django.contrib.auth import views as auth_views
from core import views as core_views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', core_views.dashboard, name='dashboard'),

    # apps urls
    path('ventas/', include('ventas.urls')),
    path('inventario/', include('inventario.urls')),
    path('clientes_proveedores/', include('clientes_proveedores.urls')),
    path('rrhh/', include('rrhh.urls')),
    path('contabilidad/', include('contabilidad.urls')),

    # Autenticación
    path('login/', auth_views.LoginView.as_view(template_name='core/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),
    path('register/', core_views.register, name='register'),
]